function mostrar()
{
	alert("cuatro");
}
